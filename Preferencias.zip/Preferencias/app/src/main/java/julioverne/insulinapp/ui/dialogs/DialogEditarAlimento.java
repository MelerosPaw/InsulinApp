package julioverne.insulinapp.ui.dialogs;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import julioverne.insulinapp.R;
import julioverne.insulinapp.constants.Constants;
import julioverne.insulinapp.data.dao.AlimentoDAO;
import julioverne.insulinapp.data.DataManager;
import julioverne.insulinapp.utils.DecimalFormatUtils;
import julioverne.insulinapp.utils.IntentUtil;
import julioverne.insulinapp.utils.InternalMemoryUtils;
import julioverne.insulinapp.utils.StringUtils;
import julioverne.insulinapp.utils.TypefacesUtils;

import static android.app.Activity.RESULT_OK;

public class DialogEditarAlimento extends DialogFragment {

    public static final String TAG = DialogEditarAlimento.class.getSimpleName();
    private static final String BUNDLE_ALIMENTO = "BUNDLE_ALIMENTO";
    private static final String BUNDLE_POSICION = "BUNDLE_POSICION";

    @BindView(R.id.et_nombre_alimento)       EditText etNombreAlimento;
    @BindView(R.id.iv_imagen_alimento)      ImageView ivImagenAlimento;
    @BindView(R.id.tv_titulo_unidad_medida) TextView tvTituloUnidadMedida;
    @BindView(R.id.et_unidadMedida)         EditText etUnidadMedida;
    @BindView(R.id.tv_titulo_cantidad)      TextView tvTituloCantidad;
    @BindView(R.id.et_cantidad)             EditText etCantidad;
    @BindView(R.id.tv_titulo_raciones)      TextView tvTituloRaciones;
    @BindView(R.id.et_raciones)             EditText etRaciones;
    @BindView(R.id.btn_aceptar)             Button btnAceptar;
    @BindView(R.id.btn_cancelar)            Button btnCancelar;

    private String nombre;
    private String unidadMedida;
    private float cantidad;
    private float raciones;
    private Bitmap bitmap;
    private AlimentoDAO alimento;
    private OnFoodSavedListener callback;
    private DataManager dataManager;
    private Unbinder unbinder;
    private int posicion;

    private final Typeface light;
    private final Typeface negrita;
    private final Typeface cursiva;

    public DialogEditarAlimento() {
        light = TypefacesUtils.get(getContext(), "fonts/DejaVuSans-ExtraLight.ttf");
        negrita = TypefacesUtils.get(getContext(), "fonts/DejaVuSansCondensed-Bold.ttf");
        cursiva = TypefacesUtils.get(getContext(), "fonts/DejaVuSansCondensed-Oblique.ttf");
        setCancelable(false);
    }

    public static DialogEditarAlimento newInstance(@Nullable AlimentoDAO alimento, int posicion) {
        Bundle args = new Bundle();
        args.putParcelable(BUNDLE_ALIMENTO, alimento);
        args.putInt(BUNDLE_POSICION, posicion);

        DialogEditarAlimento fragment = new DialogEditarAlimento();
        fragment.setArguments(args);
        return fragment;
    }

    public void setUp(Bitmap bitmap, OnFoodSavedListener callback) {
        this.bitmap = bitmap;
        this.callback = callback;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataManager = DataManager.getInstance(getContext());
        if (getArguments() != null) {
            alimento = getArguments().getParcelable(BUNDLE_ALIMENTO);
            posicion = getArguments().getInt(BUNDLE_POSICION, -1);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.dialog_definir_alimento_layout, container, false);
        unbinder = ButterKnife.bind(this, root);
        return root;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadView();
    }

    public void loadView() {

        //Tipografías
        etNombreAlimento.setTypeface(negrita);
        tvTituloUnidadMedida.setTypeface(negrita);
        etUnidadMedida.setTypeface(light);
        tvTituloCantidad.setTypeface(negrita);
        etCantidad.setTypeface(light);
        tvTituloRaciones.setTypeface(negrita);
        etRaciones.setTypeface(light);
        btnAceptar.setTypeface(light);
        btnCancelar.setTypeface(light);

        ivImagenAlimento.setImageBitmap(bitmap);

        //Si vamos a actualizar un alimento, rellenamos los campos con los valores del alimento
        if (alimento != null) {
            etNombreAlimento.setText(alimento.getNombre());
            etUnidadMedida.setText(alimento.getUnidadMedida());
            etCantidad.setText(DecimalFormatUtils.decimalToStringIfZero(
                    alimento.getCantidadUnidades().toString(), 2, ".", ","));
            etRaciones.setText(DecimalFormatUtils.decimalToStringIfZero(
                    alimento.getRacionesUnidad().toString(), 2, ".", ","));
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        // Pone el dialog en modo pantalla completa
        if (getDialog().getWindow() != null) {
            getDialog().getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
        }
    }

    @OnClick({R.id.btn_aceptar, R.id.btn_cancelar, R.id.iv_imagen_alimento})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_aceptar:
                guardarAlimento();
                break;
            case R.id.btn_cancelar:
                cancelar();
                break;
            case R.id.iv_imagen_alimento:
                cambiarImagen(ivImagenAlimento);
                break;
        }
    }

    /**
     * Guarda el alimento definido en el dialog.
     */
    public void guardarAlimento() {

        this.nombre = etNombreAlimento.getText().toString();
        this.unidadMedida = etUnidadMedida.getText().toString();
        String nuevaCantidad = etCantidad.getText().toString();
        String nuevasRaciones = etRaciones.getText().toString();

        //Si la información es correcta, añade el alimento
        if (comprobarCampos(nuevaCantidad, nuevasRaciones)) {
            //El nombre de la imagen será el nombre del alimento en minúsculas con extensión gif.
            // TODO: Hay que diferenciar entre cuando se crea un alimento nuevo y cuando se edita
            // TODO: Cuando se crea, hay que comprobar que el nombre sea único y ponerle gif
            // TODO: Cuando se edita, hay que comprobar solo si el nobre nuevo + gif existe
            // TODO: 11/11/2017 En algún momento se tendrá que comprobar si el nombre está repetido
            String nombreImagen;
            if (alimento == null) {
                nombreImagen = getNuevoNombre();
                if (dataManager.isArchivoRepetido(nombreImagen)) {
                    Log.e(TAG, "guardarAlimento: IMPOSSIBLE!! Ya existe un fichero con el nombre " + nombreImagen);
                }
            } else if (!nombre.equals(alimento.getNombre())) {
                nombreImagen = getNuevoNombre();
            } else {
                nombreImagen = alimento.getImagen();
            }

            AlimentoDAO alimentoNuevo = new AlimentoDAO(nombre, false, nombreImagen, unidadMedida, this.cantidad, this.raciones);

            boolean guardado;

            if (alimento == null) {
                guardado = dataManager.guardarAlimento(alimentoNuevo, bitmap);
            } else {
                guardado = dataManager.sobrescribirAlimento(alimento, alimentoNuevo, bitmap);
            }

            if (!guardado) {
                StringUtils.toastLargo(getContext(), R.string.advertencia_alimento_no_guardado);
                callback.onFailed(alimentoNuevo);
            } else {
                callback.onSaved(alimentoNuevo, posicion);
            }

            dismiss();
        }
    }

    private String getNuevoNombre() {
        String nombreImagen = dataManager.normalizarNombre(nombre);
        if (dataManager.isNombreImagenRepetido(dataManager.procesarNombre(nombreImagen))) {
            nombreImagen = dataManager.getUniqueName(getContext(), nombreImagen);
        }
        return dataManager.procesarNombre(nombreImagen);
    }

    /**
     * Comprueba que los datos introducidos sean correctos.
     *
     * @param cantidad Cantidad del alimento para verificarla.
     * @param raciones Cantidad de raciones por la cantidad indicad, para verificarla.
     * @return True si los campos son válidos para guardar.
     */
    private boolean comprobarCampos(String cantidad, String raciones) {

        // RETURN CASE: Si hay alguna cadena vacía, no puede seguir
        if (StringUtils.isCadenaVacia(new String[]{nombre, unidadMedida, cantidad, raciones})) {
            StringUtils.toastCorto(getContext(), R.string.advertencia_faltan_datos);
            return false;
        }

        // RETURN CASE: Si el alimento está repetido, no se puede guardar.
        if (alimento == null && dataManager.isNombreAlimentoRepetido(nombre)) {
            StringUtils.toastLargo(getContext(), String.format(getContext().getString(R.string.advertencia_repetido), nombre));
            return false;
        }

        // Ahora comprobamos la cantidad y las raciones.
        String conversionCantidad = StringUtils.convertible(cantidad);
        String conversionRaciones = StringUtils.convertible(raciones);

        // RETURN CASE: La cantidad de unidades no es una cifra.
        if (conversionCantidad.equals("string")) {
            StringUtils.toastCorto(getContext(), R.string.advertencia_cantidad_incorrecta);
            return false;
        }

        // RETURN CASE: La cantidad de raciones no es una cifra.
        if (conversionRaciones.equals("string")) {
            StringUtils.toastCorto(getContext(), R.string.advertencia_raciones_incorrectas);
            return false;
        }

        // Convierte la cantidad de unidades y las raciones en float para guardarlos en un objeto.
        this.cantidad = Float.parseFloat(cantidad.replaceAll(",", "."));
        this.raciones = Float.parseFloat(raciones.replaceAll(",", "."));

        return true;
    }

    /**
     * Cierra el cuadro de diálogo.
     */
    public void cancelar() {
        dismiss();
    }

    /**
     * Cambia la imagen del alimento.
     */
    public void cambiarImagen(View view) {
        seleccionarOrigenImagen(view);
    }

    // Activa la cámara de fotos para tomar una imagen del alimento
    public void seleccionarOrigenImagen(View view) {
        dataManager.seleccionarOrigenImagen(view, new DataManager.GetOrigenImagenCallback() {
            @Override
            public void onOrigenSelected(DataManager.OrigenImagen origen) {
                IntentUtil.IntentType intentType;

                if (origen == DataManager.OrigenImagen.DESDE_CAMARA) {
                    intentType = IntentUtil.IntentType.CAMERA;
                } else {
                    intentType = IntentUtil.IntentType.FILE_SELECT;
                }

                launchIntent(intentType);
            }
        });
    }

    /**
     * Inicia un intent para obtener la imagen desde la camara o desde el sistema de archivos.
     */
    private void launchIntent(IntentUtil.IntentType type) {

        int requestCode = type == IntentUtil.IntentType.CAMERA ?
                Constants.CAMERA_INTENT_REQUEST_CODE : Constants.FILE_SEARCH_INTENT_REQUEST_CODE;

        Intent intent = IntentUtil.getIntent(getContext(), type);
        if (intent != null) {
            switch (type) {
                case CAMERA:
                    StringUtils.toastLargo(getContext(), R.string.advertencia_foto);
                    startActivityForResult(intent, requestCode);
                    break;
                case FILE_SELECT:
                    startActivityForResult(Intent.createChooser(intent, getString(R.string.mensaje_elige_image)), requestCode);
                    break;
            }
        } else {
            switch (type) {
                case CAMERA:
                    StringUtils.toastCorto(getContext(), R.string.advertencia_sin_camara);
                    break;
                case FILE_SELECT:
                    StringUtils.toastCorto(getContext(), R.string.advertencia_sin_galeria);
                    break;
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && dataManager.isRequestCodeForThisView(requestCode)) {
            bitmap = dataManager.getBitmapFromResult(getActivity(), requestCode, data);
            bitmap = InternalMemoryUtils.prepararBitmap(bitmap);
            ivImagenAlimento.setImageBitmap(bitmap);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    public void setOnFoodSavedListener(OnFoodSavedListener callback) {
        this.callback = callback;
    }

    public interface OnFoodSavedListener {
        void onSaved(AlimentoDAO alimento, int posicion);

        void onFailed(AlimentoDAO alimento);
    }

}