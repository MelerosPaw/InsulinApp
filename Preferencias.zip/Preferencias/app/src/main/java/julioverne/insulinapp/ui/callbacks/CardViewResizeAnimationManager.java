package julioverne.insulinapp.ui.callbacks;


import android.support.annotation.NonNull;
import android.support.transition.Transition;
import android.support.transition.TransitionManager;
import android.support.transition.TransitionSet;
import android.support.v7.widget.RecyclerView;

import julioverne.insulinapp.animation.CustomTransitionSet;
import julioverne.insulinapp.widgets.ScrollControlLayoutManager;

public class CardViewResizeAnimationManager implements Transition.TransitionListener {

    protected ScrollControlLayoutManager layoutManager;
    protected RecyclerView recyclerView;
    protected TransitionSet transitionSet;
    protected boolean isAnimationOnGoing = false;

    public CardViewResizeAnimationManager(@NonNull RecyclerView recyclerView,
                                          @NonNull ScrollControlLayoutManager layoutManager,
                                          @NonNull TransitionSet transitionSet) {
        this.recyclerView = recyclerView;
        this.layoutManager = layoutManager;
        this.transitionSet = transitionSet;
        setUpListener();
    }

    public CardViewResizeAnimationManager(@NonNull RecyclerView recyclerView,
                                          @NonNull ScrollControlLayoutManager layoutManager) {
        this.recyclerView = recyclerView;
        this.layoutManager = layoutManager;
        this.transitionSet = new CustomTransitionSet();
        setUpListener();
    }

    @Override
    public void onTransitionStart(@NonNull Transition transition) {
        layoutManager.setScrollEnabled(false);
    }

    @Override
    public void onTransitionEnd(@NonNull Transition transition) {
        enableAnimation();
    }

    @Override
    public void onTransitionCancel(@NonNull Transition transition) {
        enableAnimation();
    }

    @Override
    public void onTransitionPause(@NonNull Transition transition) {
        layoutManager.setScrollEnabled(true);
    }

    @Override
    public void onTransitionResume(@NonNull Transition transition) {
        layoutManager.setScrollEnabled(false);
    }

    /**
     * Prepares the RecyclerView for a boundary change.
     *
     * @return True if the resizing can be performed, or false if there is an ongoing animation,
     * in which case, you shouldn't let other resizing animations happen to avoid display issues.
     */
    public boolean resize() {
        if (!isAnimationOnGoing) {
            isAnimationOnGoing = true;
            TransitionManager.beginDelayedTransition(recyclerView, transitionSet);
            return true;

        } else {
            return false;
        }
    }

    public void setTransitionSet(TransitionSet transitionSet) {
        this.transitionSet = transitionSet;
        setUpListener();
    }

    public boolean isAnimationOnGoing() {
        return isAnimationOnGoing;
    }

    public void setAnimationOnGoing(boolean animationOnGoing) {
        isAnimationOnGoing = animationOnGoing;
    }

    public void enableAnimation() {
        enableScroll(true);
        isAnimationOnGoing = false;
    }

    public void enableScroll(boolean enable) {
        layoutManager.setScrollEnabled(enable);
    }

    private void setUpListener() {
        transitionSet.addListener(this);
    }
}
