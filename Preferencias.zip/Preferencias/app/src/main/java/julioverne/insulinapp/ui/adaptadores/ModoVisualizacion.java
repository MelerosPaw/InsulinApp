package julioverne.insulinapp.ui.adaptadores;

public enum ModoVisualizacion {
    LISTA,
    TARJETAS
}
