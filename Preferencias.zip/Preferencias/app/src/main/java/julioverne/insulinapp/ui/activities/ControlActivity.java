package julioverne.insulinapp.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import julioverne.insulinapp.R;
import julioverne.insulinapp.data.dao.ItemAEntrada;
import julioverne.insulinapp.ui.callbacks.BooleanCallback;
import julioverne.insulinapp.ui.fragments.AlimentosFragment;
import julioverne.insulinapp.ui.fragments.DosisFragment;
import julioverne.insulinapp.ui.fragments.NivelGlucosaFragment;
import julioverne.insulinapp.ui.fragments.ResumenFragment;
import julioverne.insulinapp.utils.StringUtils;

public class ControlActivity extends BaseActivity {

    @BindView(R.id.btn_atras)       Button btnAtras;
    @BindView(R.id.btn_siguiente)   Button btnSiguiente;

    private FragmentManager fragmentManager;
    private int glucosaSangre;
    private boolean postprandial;
    private List<ItemAEntrada> alimentosSeleccionados;
    private Unbinder unbinder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_layout);
        unbinder = ButterKnife.bind(this);
        fragmentManager = getSupportFragmentManager();
        loadView();
    }

    @Override
    protected void loadView() {
//        cargarTipografíaCabecera();

        //Tipografías
        btnSiguiente.setTypeface(negrita);
        btnAtras.setTypeface(negrita);

        alimentosSeleccionados = new ArrayList<>();

        //Si se acaba de crear, mete el primer Fragment
        Fragment previousFragment = fragmentManager.findFragmentById(R.id.fragmentContainer);
        if (previousFragment == null){
            fragmentManager.beginTransaction()
                    .addToBackStack(NivelGlucosaFragment.TAG)
                    .replace(R.id.fragmentContainer,
                            NivelGlucosaFragment.getInstance(glucosaSangre),
                            NivelGlucosaFragment.TAG)
                    .commit();
        }

        btnAtras.setText(R.string.salir);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            atras();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    //Gestiona el comportamiento del botón "Siguiente" según el Fragment que esté presente
    @OnClick(R.id.btn_siguiente)
    public void siguiente() {

        boolean isCorrecto;
        Fragment currentFragment = fragmentManager.findFragmentById(R.id.fragmentContainer);
        String tag = currentFragment.getTag();

        if (tag.equals(NivelGlucosaFragment.TAG)) {
            String glucosaSangreString = ((NivelGlucosaFragment) currentFragment).getGlucosaSangre();
            isCorrecto = comprobarGlucosa(glucosaSangreString);
            if (isCorrecto) {
                btnAtras.setText(R.string.atras);
                fragmentManager.beginTransaction()
                        .addToBackStack(AlimentosFragment.TAG)
                        .replace(R.id.fragmentContainer,
                                AlimentosFragment.getInstance(postprandial, alimentosSeleccionados),
                                AlimentosFragment.TAG)
                        .commit();
            }
        } else if (tag.equals(AlimentosFragment.TAG)) {
            alimentosSeleccionados = ((AlimentosFragment) currentFragment).getAlimentosSeleccionados();
            isCorrecto = comprobarAlimentosSeleccionados();
            if (isCorrecto) {
                postprandial = ((AlimentosFragment) currentFragment).getPostprandial();
                fragmentManager.beginTransaction()
                        .addToBackStack(ResumenFragment.TAG)
                        .replace(R.id.fragmentContainer,
                                ResumenFragment.getInstance(glucosaSangre, alimentosSeleccionados, postprandial),
                                ResumenFragment.TAG)
                        .commit();
            }
        } else if (tag.equals(ResumenFragment.TAG)) {
            fragmentManager.beginTransaction()
                    .addToBackStack(DosisFragment.TAG)
                    .replace(R.id.fragmentContainer,
                            DosisFragment.getInstance(glucosaSangre, alimentosSeleccionados, postprandial),
                            DosisFragment.TAG)
                    .commit();
            btnSiguiente.setText(R.string.guardar_entrada);

        } else if (tag.equals(DosisFragment.TAG)) {
                isCorrecto = ((DosisFragment)currentFragment).guardarEntrada();
                if (isCorrecto) {
                    volverAMainActivity();
                }
        }
    }

    //Gestiona los casos del botón Atrás
    @OnClick(R.id.btn_atras)
    public void atras() {
        Fragment currentFragment = fragmentManager.findFragmentById(R.id.fragmentContainer);
        String tag = currentFragment.getTag();

        if (tag.equals(DosisFragment.TAG)) {
            onBackPressed();
            btnSiguiente.setText(R.string.siguiente);
        } else if (tag.equals(AlimentosFragment.TAG)) {
            alimentosSeleccionados = ((AlimentosFragment) currentFragment).getAlimentosSeleccionadosRaw();
            postprandial = ((AlimentosFragment) currentFragment).getPostprandial();
            super.onBackPressed();
            btnAtras.setText(R.string.salir);
        } else if (tag.equals(NivelGlucosaFragment.TAG)) {
            //Si ha rellenado datos, pregunta con un Dialog si desea salir de verdad
            if (glucosaSangre != 0 || !alimentosSeleccionados.isEmpty()) {
                preguntarAlSalir(new BooleanCallback() {
                    @Override
                    public void onCompleted(boolean result) {
                        if (result) {
                            volverAMainActivity();
                        }
                    }
                });
                //Si no, sale directamente
            } else
                volverAMainActivity();
        } else {
            super.onBackPressed();
        }
    }

    /**Comprueba que la glucosa indicada no sea una cadena vacía. Si lo es, muestra un {@code Toast}.
     * Si no, asigna el nuevo valor a la variable de la clase {@code glucosaSangre}.
     * @param glucosaSangreString Cantidad de glucosa en {@code String} que queremos comprobar.
     * @return Devuelve {@code true} si no es una cadena vacía y se puede convertir en {@code Integer}.*/
    private boolean comprobarGlucosa(String glucosaSangreString) {
        if (StringUtils.isCadenaVacia(glucosaSangreString)){
            StringUtils.toastCorto(this, R.string.advertencias_sin_glucosa);
            return false;
        }

        glucosaSangre = Integer.parseInt(glucosaSangreString);
        return true;
    }

    /**Comprueba que la {@code List alimentosSelecccionados} no valga {@code null}.
     * @return Devuelve {@code true} si no vale {@code null}. */
    private boolean comprobarAlimentosSeleccionados() {
        return alimentosSeleccionados != null;
    }

    /**Vuelve a la MainActivity borando la BackStack*/
    private void volverAMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        atras();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        mostrarInsulinaActual();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
    }
}
