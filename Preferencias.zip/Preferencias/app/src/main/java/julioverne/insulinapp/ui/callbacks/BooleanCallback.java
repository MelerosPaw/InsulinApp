package julioverne.insulinapp.ui.callbacks;

/**
 * Created by Juan José Melero on 09/06/2015.
 */
public interface BooleanCallback {

    void onCompleted(boolean result);
}
