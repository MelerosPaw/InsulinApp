package julioverne.insulinapp.ui.callbacks;

/**
 * Created by Juan José Melero on 13/06/2015.
 */
public interface VolleyImageSavedCallback {

    public void onSuccess();
    public void onFailure();
}
