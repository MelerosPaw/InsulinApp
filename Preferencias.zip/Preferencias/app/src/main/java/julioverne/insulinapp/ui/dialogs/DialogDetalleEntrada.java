package julioverne.insulinapp.ui.dialogs;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import julioverne.insulinapp.R;
import julioverne.insulinapp.data.dao.EntradaDAO;
import julioverne.insulinapp.utils.DateUtils;
import julioverne.insulinapp.utils.StringUtils;
import julioverne.insulinapp.utils.TypefacesUtils;

public class DialogDetalleEntrada extends DialogFragment {

    public static final String TAG = DialogDetalleEntrada.class.getSimpleName();
    private static final String BUNDLE_ENTRADA = "BUNDLE_ENTRADA";

    @BindView (R.id.tv_titulo)              TextView tvTitulo;
    @BindView (R.id.tv_glucosa_sangre)      TextView tvGlucosaSangre;
    @BindView (R.id.tv_insulina_dosis)      TextView tvInsulinaDosis;
    @BindView (R.id.tv_insulina_sangre)     TextView tvInsulinaSangre;
    @BindView (R.id.tv_antes_comer)         TextView tvAntesComer;
    @BindView (R.id.tv_titulo_alimentos)    TextView tvTituloAlimentos;
    @BindView (R.id.tv_alimentos)           TextView tvAlimentos;

    private OnCloseListener closeListener;
    private EntradaDAO entrada;
    private Unbinder unbinder;
    private Typeface light;
    private Typeface negrita;
    private Typeface cursiva;

    public static DialogDetalleEntrada newInstance(@Nullable EntradaDAO entrada) {
        Bundle args = new Bundle();
        args.putParcelable(BUNDLE_ENTRADA, entrada);

        DialogDetalleEntrada fragment = new DialogDetalleEntrada();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            entrada = getArguments().getParcelable(BUNDLE_ENTRADA);
        }
        light = TypefacesUtils.get(getContext(), "fonts/DejaVuSans-ExtraLight.ttf");
        negrita = TypefacesUtils.get(getContext(), "fonts/DejaVuSansCondensed-Bold.ttf");
        cursiva = TypefacesUtils.get(getContext(), "fonts/DejaVuSansCondensed-Oblique.ttf");
        setCancelable(false);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.dialog_detalle_entrada_layout, container, false);
        unbinder = ButterKnife.bind(this, root);
        return root;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadView();
    }

    public void loadView() {
        tvTitulo.setText(DateUtils.dateToString(entrada.getFecha()) + " - " + DateUtils.dateToHour(entrada.getFecha()));
        tvGlucosaSangre.setText(entrada.getGlucosaSangre().toString());
        tvInsulinaDosis.setText(entrada.getInsulinaDosis().toString());
        tvInsulinaSangre.setText(entrada.getUnidadesSangre().toString());
        tvAntesComer.setText(entrada.isAntesDeComer() ? R.string.si : R.string.no);
        boolean hayAlimentos = !StringUtils.isCadenaVacia(entrada.getResumenAlimentos());
        tvTituloAlimentos.setVisibility(hayAlimentos ? View.VISIBLE : View.GONE);
        tvAlimentos.setVisibility(hayAlimentos ? View.VISIBLE : View.GONE);
        tvAlimentos.setText(hayAlimentos ? entrada.getResumenAlimentos() : "");
    }

    @Override
    public void onStart() {
        super.onStart();
        // Pone el dialog en modo wrap_content
        if (getDialog().getWindow() != null) {
            getDialog().getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
        }
    }

    @OnClick(R.id.btn_cerrar)
    public void onClick() {
        closeListener.onClose();
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    public void setOnCloseListener(OnCloseListener closeListener) {
        this.closeListener = closeListener;
    }

    public interface OnCloseListener {
        void onClose();
    }
}