package julioverne.insulinapp.utils;

import android.widget.EditText;

import butterknife.ButterKnife;

/**
 * Created by Juan José Melero on 17/06/2015.
 */
public class ButterKnifeUtils {

    /** Pone el mismo texto a todas las vistas que se le pasen */
    public static final ButterKnife.Setter<EditText, String> SET_TEXT = new ButterKnife.Setter<EditText, String>() {
        @Override
        public void set(EditText view, String value, int index) {
            view.setText(value);
        }
    };
}
