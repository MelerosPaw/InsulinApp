package julioverne.insulinapp.ui.adaptadores;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import julioverne.insulinapp.R;
import julioverne.insulinapp.data.dao.AlimentoDAO;
import julioverne.insulinapp.data.dao.ItemAEntrada;
import julioverne.insulinapp.ui.fragments.AlimentosFragment;
import julioverne.insulinapp.utils.DecimalFormatUtils;
import julioverne.insulinapp.utils.StringUtils;
import julioverne.insulinapp.utils.TypefacesUtils;

public class AdaptadorAlimentosControl extends ArrayAdapter<ItemAEntrada> {

    private ArrayList<ItemAEntrada> datos;
    private Context context;
    private int resource;
    private ListView listView;
    private Fragment fragment;
    private final Typeface LIGHT;
    private final Typeface CURSIVA;
    private static int mostrado = 0;

    public AdaptadorAlimentosControl(Context context, int resource, Fragment fragment,
                                     ArrayList<ItemAEntrada> alimentos) {
        super(context, resource, alimentos);
        this.context = context;
        this.datos = alimentos;
        this.resource = resource;
        this.fragment = fragment;
        LIGHT = TypefacesUtils.get(context, "fonts/DejaVuSans-ExtraLight.ttf");
        CURSIVA = TypefacesUtils.get(context, "fonts/DejaVuSansCondensed-Oblique.ttf");
    }


    private static class ViewHolder{
        TextView tvNombreAlimento;
        TextView tvUnidadMedida;
        EditText etCantidadAlimento;
        ImageButton btnEliminar;
        int posicion;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        if (this.listView == null){
            this.listView = (ListView) parent;
        }

        View item = convertView;
        final ViewHolder holder;

        if (item == null){
            item = LayoutInflater.from(context).inflate(resource, null);
            holder = new ViewHolder();

            holder.tvNombreAlimento = (TextView) item.findViewById(R.id.tv_nombre_alimento);
            holder.tvUnidadMedida = (TextView) item.findViewById(R.id.tv_unidad_medida);
            holder.etCantidadAlimento = (EditText) item.findViewById(R.id.et_cantidad_alimento);
            holder.btnEliminar = (ImageButton) item.findViewById(R.id.btn_eliminar);
            item.setTag(holder);
        }else
            holder = (ViewHolder) item.getTag();


        //Tipografías
        holder.tvNombreAlimento.setTypeface(LIGHT);
        holder.tvUnidadMedida.setTypeface(CURSIVA);
        holder.etCantidadAlimento.setTypeface(LIGHT);

        final ItemAEntrada contiene = datos.get(position);
        holder.tvNombreAlimento.setText(contiene.getAlimento().getNombre());
        holder.tvUnidadMedida.setText(contiene.getAlimento().getUnidadMedida());
        holder.posicion = position;
        if (contiene.getCantidad() != 0) {
            holder.etCantidadAlimento.setText(DecimalFormatUtils.decimalToStringIfZero(contiene.getCantidad(), 2, ".", ","));
        } else {
            holder.etCantidadAlimento.setText("");
        }

        //Al cambiar el foco recoge el valor solo si la cantidad introducida es correcta.
        holder.etCantidadAlimento.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String contenido = holder.etCantidadAlimento.getText().toString();

                    //Si la cadena está vacía, asigna el valor 0 a la cantidad
                    if (contenido.isEmpty()){
                        contiene.setCantidad(0f);
                    //Si no, comprueba si es decimal o entero y lo asigna
                    } else {
                        String convertible = StringUtils.convertible(contenido);
                        String cantidad;

                        if (convertible.equals("float")) {
                            cantidad = DecimalFormatUtils.decimalToStringIfZero(contenido, 2, ",", ".");
                        } else if (convertible.equals("integer")) {
                            cantidad = contenido;
                        //Si es una cantidad incorrecta, guarda 0 también
                        } else {
                            cantidad = "0";
                        }

                        contiene.setCantidad(Float.parseFloat(cantidad));
                    }
                }
            }
        });

        holder.btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                remove(contiene);
                ((AlimentosFragment) fragment).actualizarAutoCompleteTextView(contiene.getAlimento().getNombre());
            }
        });

        return item;
    }


    /**Añade un alimento a la lista.*/
    public void nuevoAlimento(AlimentoDAO alimentoDAO){
        ItemAEntrada contiene = new ItemAEntrada();
        contiene.setAlimento(alimentoDAO);
        contiene.setCantidad(0f);
        add(contiene);
    }


    /**Devuelve una {@code List} con los alimentos y las cantidades que se han indicado.
     * @return Si faltan cantidades por indicar o no se han guardado todos los alimentos de la lista
     * devuelve <i>null</i>. Si no, devuelve la lista con los alimentos y las cantidades.*/
    public List<ItemAEntrada> getAlimentos() {

        if (hayCantidadesVacias()){
            StringUtils.toastCorto(context, R.string.advertencia_faltan_cantidades);
            return null;
        }

        return datos;
    }

    public List<AlimentoDAO> getAlimentosIncluidos() {
        List<AlimentoDAO> alimentosIncluidos = new LinkedList<>();
        for (ItemAEntrada entrada : datos) {
            alimentosIncluidos.add(entrada.getAlimento());
        }

        return alimentosIncluidos;
    }


    /**Devuelve <i>true</i> si algún alimento no tiene cantidad indicada. Si un <i>ContieneAlimentoDAO</i>
     * de <i>datos</i> tiene una cantida de 0, devuelve lo contrario.
     * @return Devuelve <i>true</i> si por cada alimento que hay en <i>datos</i> hay una cantidad
     * que no es 0.*/
    private boolean hayCantidadesVacias() {

        for (ItemAEntrada contiene : datos)
            if (contiene.getCantidad() != null && contiene.getCantidad() <= 0)
                return true;

        return false;
    }

    public ArrayList<ItemAEntrada> getDatos(){
        return datos;
    }
}
